Glamis Map Downloads

What is included
- glamis_landmarks_v1.gpx  
- glamis_landmarks.kmz     
- glamis_landmarks.geojson 

Coordinate system
- WGS84, decimal degrees

How to import
- Garmin BaseCamp and most Garmin handhelds  use the GPX file
- Gaia GPS and onX Offroad  use the GPX file
- Google Earth  open the KMZ file
- Avenza Maps  GPX or KMZ

Notes
- Names are kept short for device readability
- Descriptions include any available notes, category, and symbol
- This set contains waypoints only

Safety
- Conditions change quickly in the dunes
- You are responsible for your own safety and for following local rules
- Use these files as a planning aid only
- Copyright Glamis.com 2025-2026
